# ChatBot
A simple chat application using HTML, CSS, JavaScript and jQuery. It is a single page, that opens in the browser, and shows the messages in colored bubbles (Like WhatsApp). On one side the computer will generate a random conversation, on the other side the user can post messages. The screen automatically flows and follows the messages posted, like in all chat apps.
