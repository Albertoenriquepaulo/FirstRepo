$(document).ready(function(){
var someText = $(".container .right .write input").val(text);
$('.container .right .chat .name').append(document.createTextNode(someText));
});
