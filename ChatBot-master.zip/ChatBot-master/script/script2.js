$(document).ready(function(){
  $('.container .right .write .write-link.send').click(function(){
    $('body').data('mi dato', "Holaaaaaaaaa");
    $('.container .right .chat .name').append(mi dato);

  });


});
